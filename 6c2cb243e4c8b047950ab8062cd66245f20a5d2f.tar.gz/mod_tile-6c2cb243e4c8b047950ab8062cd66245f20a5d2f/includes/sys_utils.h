#ifndef SYS_UTILS_H
#define SYS_UTILS_H

double get_load_avg(void);

#endif
